chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'exportCSV') {
    console.log('Starting CSV export process...');
    exportToCSV();
  }
});

function exportToCSV() {
  try {
    console.log('Retrieving stored data...');
    chrome.storage.local.get(['extractedData'], function(result) {
      if (!result.extractedData || !result.extractedData.length) {
        console.warn('No data available for export');
        chrome.runtime.sendMessage({
          action: 'exportError',
          message: 'No data available for export'
        });
        return;
      }

      console.log(`Processing ${result.extractedData.length} records for export...`);
      chrome.runtime.sendMessage({
        action: 'exportProgress',
        message: `Processing ${result.extractedData.length} records...`
      });

      // Updated CSV headers with new Listing Cancel Date column
      const headers = [
        'MLS',
        'Address',
        'Status',
        'Property Type',
        'Style',
        'Age (Years)',
        'Year Built',
        'Ownership',
        'Bedrooms',
        'Bathrooms',
        'House Size (sqft)',
        'Lot Size (sqft)',
        'List Price',
        'Sale Price',
        'Ask Price',
        'Original Price',
        'Price per Sqft',
        'Listing Date',
        'Sale Date',
        'Sale Reported Date',
        'Listing Cancel Date',
        'Days on Market'
      ];

      try {
        // Create CSV content with UTF-8 BOM for Excel compatibility
        let csvContent = '\ufeff';

        // Helper function to escape and format CSV values
        const formatCSVValue = (value) => {
          if (value === null || value === undefined || value === '') {
            return '';
          }
          const stringValue = value.toString().trim()
            .replace(/[\u2018\u2019]/g, "'")   // Smart single quotes
            .replace(/[\u201C\u201D]/g, '"')   // Smart double quotes
            .replace(/\u2022/g, '-')           // Bullet points
            .replace(/\u2026/g, '...')         // Ellipsis
            .replace(/[\r\n]+/g, ' ');         // Line breaks

          // Escape quotes and handle commas
          if (stringValue.includes(',') || stringValue.includes('"') || stringValue.includes('\n')) {
            return `"${stringValue.replace(/"/g, '""')}"`;
          }
          return stringValue;
        };

        // Add headers
        csvContent += headers.map(header => `"${header}"`).join(',') + '\n';

        // Add data rows with new column
        result.extractedData.forEach(row => {
          const rowData = [
            row.mls,
            row.address,
            row.status,
            row.propertyType,
            row.style,
            row.age,
            row.yearBuilt,
            row.ownership,
            row.bedrooms,
            row.bathrooms,
            row.houseSqft,
            row.lotSqft,
            row.listPrice,
            row.salePrice,
            row.askPrice,
            row.originalPrice,
            row.pricePerSqft,
            row.listingDate,
            row.saleDate,
            row.saleReportedDate,
            row.listingCancelDate,
            row.daysOnMarket
          ].map(formatCSVValue);

          csvContent += rowData.join(',') + '\n';
        });

        console.log('CSV content generated successfully');
        chrome.runtime.sendMessage({
          action: 'exportProgress',
          message: 'Preparing download...'
        });

        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const filename = `zealty-export-${timestamp}.csv`;

        // Convert CSV content to a data URI
        const dataUri = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csvContent);

        console.log('Initiating download...');
        chrome.downloads.download({
          url: dataUri,
          filename: filename,
          saveAs: true
        }, (downloadId) => {
          if (chrome.runtime.lastError) {
            console.error('Download API error:', chrome.runtime.lastError);
            chrome.runtime.sendMessage({
              action: 'exportError',
              message: 'Failed to start download: ' + chrome.runtime.lastError.message
            });
            return;
          }

          if (downloadId === undefined) {
            console.error('Download failed - no download ID received');
            chrome.runtime.sendMessage({
              action: 'exportError',
              message: 'Download failed to start. Please try again.'
            });
            return;
          }

          console.log('Download started successfully with ID:', downloadId);
          // Send success message with a slight delay to ensure UI updates
          setTimeout(() => {
            chrome.runtime.sendMessage({
              action: 'exportSuccess',
              downloadId: downloadId
            });
          }, 500);
        });
      } catch (csvError) {
        console.error('CSV generation error:', csvError);
        chrome.runtime.sendMessage({
          action: 'exportError',
          message: `Failed to generate CSV: ${csvError.message}`
        });
      }
    });
  } catch (error) {
    console.error('Export error:', error);
    chrome.runtime.sendMessage({
      action: 'exportError',
      message: `Export error: ${error.message}`
    });
  }
}