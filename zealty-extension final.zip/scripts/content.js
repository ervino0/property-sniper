// Content script for Zealty data extraction

let isExtracting = false;
let observer = null;

// Initialize extraction state from storage
chrome.storage.local.get(['isExtracting'], function(result) {
  isExtracting = result.isExtracting || false;
  if (isExtracting) {
    setupObserver();
    extractCurrentPage();
  }
});

// Listen for messages from popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'startExtraction') {
    console.log('Starting extraction...');
    isExtracting = true;
    setupObserver();
    extractCurrentPage();
  } else if (message.action === 'stopExtraction') {
    console.log('Stopping extraction...');
    isExtracting = false;
    if (observer) {
      observer.disconnect();
      observer = null;
    }
  }
});

function setupObserver() {
  if (observer) {
    observer.disconnect();
  }

  const targetNode = document.querySelector('.table-container');
  if (!targetNode) {
    console.error('Table container not found');
    return;
  }

  observer = new MutationObserver((mutations) => {
    if (!isExtracting) return;

    for (const mutation of mutations) {
      if (mutation.type === 'childList' || mutation.type === 'subtree') {
        console.log('DOM changed, extracting new data...');
        setTimeout(extractCurrentPage, 1000);
        break;
      }
    }
  });

  observer.observe(targetNode, {
    childList: true,
    subtree: true
  });
}

class AddressComponent {
  constructor() {
    this.unit = null;
    this.number = null;
    this.streetName = null;
    this.city = 'Vancouver';
    this.postalCode = null;
    this.isTownhouse = false;
  }

  formatOrdinal(num) {
    try {
      const n = parseInt(num, 10);
      let suffix = 'th';
      if (n % 10 === 1 && n % 100 !== 11) suffix = 'st';
      else if (n % 10 === 2 && n % 100 !== 12) suffix = 'nd';
      else if (n % 10 === 3 && n % 100 !== 13) suffix = 'rd';
      return `${num}${suffix}`;
    } catch {
      return num;
    }
  }

  formatStreetPart(part) {
    // Handle cardinal directions (both single and multi-character)
    const directions = new Set(['N', 'S', 'E', 'W', 'NE', 'NW', 'SE', 'SW']);
    const partUpper = part.toUpperCase();
    if (directions.has(partUpper)) {
      return partUpper;
    }

    // Handle numeric parts (e.g., 33rd)
    if (/^\d+$/.test(part)) {
      return this.formatOrdinal(part);
    }

    // Handle street types with proper capitalization
    const streetTypes = ['Street', 'Avenue', 'Drive', 'Road', 'Way', 'Place'];
    const partLower = part.toLowerCase();
    for (const streetType of streetTypes) {
      if (partLower === streetType.toLowerCase()) {
        return streetType;
      }
    }

    // Special cases like "St" in "St Johns"
    if (partLower === 'st' && this.streetName && this.streetName.toLowerCase().includes('johns')) {
      return 'St';
    }

    // Standard capitalization for other parts
    return part.charAt(0).toUpperCase() + part.slice(1).toLowerCase();
  }

  toString() {
    const parts = [];

    // Add unit/number
    if (this.unit) {
      const prefix = this.isTownhouse ? "TH" : "";
      parts.push(`${prefix}${this.unit}-${this.number}`);
    } else {
      parts.push(this.number);
    }

    // Add formatted street name
    if (this.streetName) {
      const streetParts = this.streetName.split(' ').map(p => this.formatStreetPart(p));
      parts.push(streetParts.join(' '));
    }

    // Add city, province, postal code
    parts.push(this.city, "BC", this.postalCode || '');

    return parts.filter(Boolean).join(' ');
  }
}

function extractComponents(address) {
  const components = new AddressComponent();

  console.debug('Processing address:', address);

  // Extract postal code first (it's the most reliable part)
  const postalMatch = address.match(/V\d[A-Z]\s*\d[A-Z]\d/i);
  if (postalMatch) {
    components.postalCode = postalMatch[0].replace(/\s+/g, '').toUpperCase();
    // Remove everything after postal code, as it's usually noise
    address = address.slice(0, postalMatch.index);
    console.debug('Found postal code:', components.postalCode);
  }

  // Extract city (try longer/specific names first)
  const cities = ['Port Moody', 'Richmond', 'Surrey', 'Vancouver'];
  for (const city of cities) {
    const cityPattern = new RegExp(`\\b${city}\\b`, 'i');
    if (cityPattern.test(address)) {
      components.city = city;
      // Remove city name and any directional suffix
      address = address.replace(new RegExp(`${cityPattern.source}\\s*(?:East|West)?\\b`, 'gi'), '');
      console.debug('Found city:', components.city);
      break;
    }
  }

  // Clean up the remaining address string
  const patternsToRemove = [
    /\([^)]+\)/g,                           // Remove parenthetical content
    /strata\s+plan\s+[^\s]*/i,             // Remove strata plan info
    /(?:BC|B\.?C\.?)\s*/i,                 // Remove BC
    /region(?:\s+for\s+sale)?\s*/i,        // Remove region
    /for\s+sale\s*/i,                      // Remove for sale
    /(?:expired|terminated|cancelled|sold)\s*/i,  // Remove status
    /(?:clyde|carlyle|connaught place)\s*/i,     // Remove known place names
    /[,.]/g,                               // Remove punctuation
  ];

  for (const pattern of patternsToRemove) {
    address = address.replace(pattern, ' ');
  }

  // Clean up whitespace and remove any remaining city names
  address = address.replace(/\s+/g, ' ').trim();
  // Remove city names that might be part of the street address
  for (const city of cities) {
    address = address.replace(new RegExp(`\\s*${city}\\b`, 'gi'), '');
  }

  console.debug('Cleaned address:', address);

  // Extract unit/number and street name
  components.isTownhouse = /^TH/i.test(address);

  // Try patterns in order of specificity
  const patterns = [
    // TH1-101 Main Street
    [/^(?:TH)?(\d+)-(\d+)\s+(.+)$/i, (m) => [m[1], m[2], m[3]]],
    // 101 Main Street
    [/^(\d+)\s+(.+)$/i, (m) => [null, m[1], m[2]]],
  ];

  for (const [pattern, extractor] of patterns) {
    const match = address.match(pattern);
    if (match) {
      [components.unit, components.number, components.streetName] = extractor(match);
      console.debug('Matched pattern:', {
        unit: components.unit,
        number: components.number,
        street: components.streetName
      });
      break;
    }
  }

  return components;
}

function cleanAddress(rawAddress) {
  if (!rawAddress) return '';

  console.debug('Input address:', rawAddress);
  const components = extractComponents(rawAddress);
  const result = components.toString();
  console.debug('Final address:', result);
  return result;
}

function determineListingStatus(priceText, dateText, propertyInfo) {
  // Check for Off Market date first
  const offMarketMatch = /Off Market.*?(\d{4}-[A-Za-z]+-\d+)/i.exec(dateText);
  if (offMarketMatch) {
    return 'expired';
  }

  const statusIndicators = {
    sold: [
      /Sale Reported/i,
      /Sale Date/i,
      /Sold/i
    ],
    expired: [
      /Off Market.*Expired/i,
      /Expired/i
    ],
    terminated: [
      /Off Market.*Terminated/i,
      /Terminated/i
    ],
    cancelled: [
      /Off Market.*Cancelled/i,
      /Cancelled/i
    ]
  };

  // Check each status type
  for (const [status, patterns] of Object.entries(statusIndicators)) {
    if (patterns.some(pattern => pattern.test(dateText) || pattern.test(propertyInfo))) {
      return status;
    }
  }

  // If there's a sale price but no explicit status, mark as sold
  if (/Sale Price[^$]*\$([\d,]+)/i.test(priceText)) {
    return 'sold';
  }

  return 'active';
}

function parsePropertyInfo(text) {
  if (!text) {
    return { propertyType: '', age: '', yearBuilt: '' };
  }

  console.debug('Parsing property info:', text);

  // Extract property type with special cases
  let propertyType = '';

  // Handle special combined types first
  if (text.includes('1/2 Duplex')) {
    propertyType = '1/2 Duplex';
    console.debug('Found 1/2 Duplex property type');
  } else if (text.includes('House/Single Family')) {
    propertyType = 'House/Single Family';
  } else if (text.includes('Row House')) {
    propertyType = 'Row House';
  } else {
    // Look for standard types
    const types = ['Townhouse', 'House', 'Apartment'];
    propertyType = types.find(type => text.includes(type)) || '';
  }

  // Extract age and year built
  let age = '', yearBuilt = '';
  if (text.includes('Newly Built')) {
    age = '0';
  } else {
    const ageMatch = text.match(/(\d+)\s*years?\s*old\s*(?:\((\d{4})\))?/);
    if (ageMatch) {
      age = ageMatch[1];
      yearBuilt = ageMatch[2] || '';
    }
  }

  const result = { propertyType, age, yearBuilt };
  console.debug('Parsed property info:', result);
  return result;
}

function parseSizeInfo(text) {
  if (!text) {
    return { bedrooms: '', bathrooms: '', houseSqft: '', lotSqft: '' };
  }

  const bedMatch = text.match(/(\d+)\s*bed/i);
  const bathMatch = text.match(/(\d+)\s*bath/i);

  // Extract house size with improved HTML handling
  const houseSizeMatch = text.match(/House Size(?:[^]*?(?:<[^>]+>|\s*))?(\d+(?:,\d+)?)\s*sqft/i);

  // Extract lot size with improved HTML handling
  const lotSizeAcreMatch = text.match(/Lot Size[^]*?(?:<[^>]+>|\s*)?(\d+(?:\.\d+)?)\s*acre/i);
  const lotSizeSqftMatch = text.match(/Lot Size[^]*?\((\d+(?:,\d+)?)\s*sqft\)/i);

  // Convert acre to sqft if needed
  let lotSqft = '';
  if (lotSizeSqftMatch) {
    lotSqft = lotSizeSqftMatch[1].replace(/,/g, '');
  } else if (lotSizeAcreMatch) {
    lotSqft = Math.round(parseFloat(lotSizeAcreMatch[1]) * 43560).toString();
  }

  return {
    bedrooms: bedMatch?.[1] || '',
    bathrooms: bathMatch?.[1] || '',
    houseSqft: houseSizeMatch?.[1]?.replace(/,/g, '') || '',
    lotSqft: lotSqft
  };
}

function parsePriceInfo(text) {
  const listPriceMatch = text.match(/^\$[\d,]+/);
  const salePriceMatch = text.match(/Sale Price[^$]*\$([\d,]+)/i);
  const askPriceMatch = text.match(/(?:ask|list)[^$]*\$([\d]+)/i);
  const origPriceMatch = text.match(/orig[^$]*\$([\d,]+)/i);
  const pricePerSqftMatch = text.match(/(?:price per House sqft|price\/sqft)[^$]*\$([\d,.]+)/i);

  return {
    listPrice: listPriceMatch?.[0]?.replace(/[,$]/g, '') || '',
    salePrice: salePriceMatch?.[1]?.replace(/,/g, '') || '',
    askPrice: askPriceMatch?.[1]?.replace(/,/g, '') || '',
    originalPrice: origPriceMatch?.[1]?.replace(/,/g, '') || '',
    pricePerSqft: pricePerSqftMatch?.[1] || ''
  };
}

// Extract off-market date with improved HTML structure handling
function extractOffMarketDate(dateCell) {
  const offMarketDiv = dateCell.querySelector('div:first-child');
  if (offMarketDiv && offMarketDiv.textContent.includes('Off Market')) {
    const dateDiv = offMarketDiv.querySelector('div[style*="monospace"]');
    return dateDiv ? dateDiv.textContent.trim() : '';
  }
  return '';
}

// Enhanced parseDateInfo function with more robust Off Market detection
function parseDateInfo(text) {
  if (!text) {
    console.debug('Empty date text, returning empty values');
    return {
      listingDate: '',
      saleDate: '',
      saleReportedDate: '',
      listingCancelDate: '',
      daysOnMarket: ''
    };
  }

  console.debug('Parsing date info from:', text);

  // Create a temporary div to parse HTML content
  const tempDiv = document.createElement('div');
  tempDiv.innerHTML = text;

  const dates = {
    listingDate: '',
    saleDate: '',
    saleReportedDate: '',
    listingCancelDate: '',
    daysOnMarket: ''
  };

  // Helper function to extract date from text with improved pattern matching
  function extractDate(pattern) {
    // Try HTML format first
    const htmlPattern = new RegExp(
      `<div[^>]*>${pattern}[^>]*?<div[^>]*>(\\d{4}-[A-Za-z]+-\\d+)</div>`,
      'i'
    );
    const htmlMatch = text.match(htmlPattern);
    if (htmlMatch) {
      return formatDate(htmlMatch[1].trim());
    }

    // Try plain text format
    const plainPattern = new RegExp(
      `${pattern}\\s*[:]?\\s*(\\d{4}-[A-Za-z]+-\\d+)`,
      'i'
    );
    const plainMatch = text.match(plainPattern);
    if (plainMatch) {
      return formatDate(plainMatch[1].trim());
    }

    return '';
  }

  // Extract listing date
  dates.listingDate = extractDate('(?:Listed\\s+On|Listing\\s+Entered)');

  // Extract sale dates
  dates.saleDate = extractDate('Sale\\s+Date(?!\\s+Reported)');
  dates.saleReportedDate = extractDate('Sale\\s+Reported');

  // Extract off market date with improved pattern matching
  const offMarketPatterns = [
    /<div[^>]*>Off\s+Market(?:\s*\([^)]*\))?\s*<div[^>]*>(\d{4}-[A-Za-z]+-\d+)<\/div>/i,
    /Off\s+Market(?:\s*\([^)]*\))?\s*(?:<[^>]*>)*(\d{4}-[A-Za-z]+-\d+)/i,
    /Off\s+Market.*?(\d{4}-[A-Za-z]+-\d+)/i
  ];

  for (const pattern of offMarketPatterns) {
    const match = text.match(pattern);
    if (match) {
      const offMarketDate = formatDate(match[1].trim());
      if (offMarketDate) {
        dates.listingCancelDate = offMarketDate;
        break;
      }
    }
  }

  // Extract days on market
  const domMatch = text.match(/\((\d+)\s*days? on market\)/i);
  if (domMatch) {
    dates.daysOnMarket = domMatch[1];
  }

  // Clear sale reported date if it's an off-market listing
  if (dates.listingCancelDate) {
    dates.saleReportedDate = '';
  }

  console.debug('Final extracted dates:', dates);
  return dates;
}

// Helper function to extract date from div
function extractDateFromDiv(div) {
  if (!div) return '';
  const monospaceDiv = div.querySelector('div[style*="monospace"]');
  return monospaceDiv ? formatDate(monospaceDiv.textContent.trim()) : '';
}

function formatDate(dateStr) {
  if (!dateStr) return '';
  if (dateStr.match(/^\d{4}-$/)) return '';

  const monthMap = {
    'Jan': '01', 'Feb': '02', 'Mar': '03', 'Apr': '04',
    'May': '05', 'Jun': '06', 'Jul': '07', 'Aug': '08',
    'Sep': '09', 'Oct': '10', 'Nov': '11', 'Dec': '12'
  };

  const match = dateStr.match(/^(\d{4})-([A-Za-z]+)-(\d+)$/);
  if (match) {
    const [, year, month, day] = match;
    if (monthMap[month]) {
      return `${year}-${monthMap[month]}-${day.padStart(2, '0')}`;
    }
  }
  return dateStr;
}


function extractCurrentPage() {
  if (!isExtracting) return;

  const table = document.querySelector('.table-container .stripedTable');
  if (!table) {
    console.error('Table not found');
    return;
  }

  const rows = Array.from(table.querySelectorAll('tr')).filter(row =>
    !row.classList.contains('header-row') && row.cells.length >= 8
  );

  console.log(`Found ${rows.length} data rows`);
  const pageData = [];

  rows.forEach((row, index) => {
    try {
      const cells = row.cells;
      const mlsButton = cells[1].querySelector('button.linkMLS');
      if (!mlsButton) return;

      const rawAddress = cells[2].textContent?.trim() || '';
      const propertyInfoText = cells[3].textContent?.trim() || '';
      const sizeInfoText = cells[4].textContent?.trim() || '';
      const priceText = cells[5].textContent?.trim() || '';
      const dateText = cells[6].textContent?.trim() || '';

      const data = {
        mls: mlsButton.textContent?.trim() || '',
        address: cleanAddress(rawAddress),
        status: determineListingStatus(priceText, dateText, propertyInfoText),
        ...parsePropertyInfo(propertyInfoText),
        ...parseSizeInfo(sizeInfoText),
        ...parsePriceInfo(priceText),
        ...parseDateInfo(dateText)
      };

      if (data.mls) {
        pageData.push(data);
      }
    } catch (error) {
      console.error('Error processing row:', error);
    }
  });

  if (pageData.length > 0) {
    updateStorage(pageData);
  }
}

function updateStorage(pageData, retryCount = 0) {
  chrome.storage.local.get(['extractedData'], function(result) {
    if (chrome.runtime.lastError) {
      console.error('Storage get error:', chrome.runtime.lastError);
      if (retryCount < 3) {
        setTimeout(() => updateStorage(pageData, retryCount + 1), 1000);
      }
      return;
    }

    const existingData = result.extractedData || [];
    // Deduplicate based on MLS number
    const uniqueData = [...existingData];
    pageData.forEach(newItem => {
      const existingIndex = uniqueData.findIndex(item => item.mls === newItem.mls);
      if (existingIndex >= 0) {
        uniqueData[existingIndex] = newItem; // Update existing entry
      } else {
        uniqueData.push(newItem); // Add new entry
      }
    });

    chrome.storage.local.set({
      extractedData: uniqueData,
      isExtracting: true
    }, () => {
      if (chrome.runtime.lastError) {
        console.error('Storage set error:', chrome.runtime.lastError);
        if (retryCount < 3) {
          setTimeout(() => updateStorage(pageData, retryCount + 1), 1000);
        }
      } else {
        chrome.runtime.sendMessage({
          action: 'updateRecordCount',
          count: uniqueData.length
        });
      }
    });
  });
}

// Listen for page navigation events
document.addEventListener('click', (event) => {
  if (!isExtracting) return;

  const target = event.target;
  let buttonElement = target.closest('button');
  if (!buttonElement && target.tagName === 'I') {
    buttonElement = target.parentElement;
  }

  if (!buttonElement) return;

  const isPaginationButton =
    buttonElement.closest('#footer') &&
    buttonElement.classList.contains('tall') &&
    (
      buttonElement.innerHTML.includes('Next 20') ||
      buttonElement.innerHTML.includes('Prev 20') ||
      (buttonElement.onclick && buttonElement.onclick.toString().includes('doSearch'))
    );

  if (isPaginationButton) {
    console.log('Pagination button clicked, waiting for page update...');
    setTimeout(() => {
      setupObserver();
      setTimeout(extractCurrentPage, 1000);
    }, 500);
  }
});