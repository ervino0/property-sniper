// Handle extension popup initialization and UI updates
document.addEventListener('DOMContentLoaded', function() {
  const startBtn = document.getElementById('startBtn');
  const stopBtn = document.getElementById('stopBtn');
  const exportBtn = document.getElementById('exportBtn');
  const statusSpan = document.getElementById('status');
  const recordCountSpan = document.getElementById('recordCount');

  let exportTimeout = null;

  // Initialize buttons state
  stopBtn.disabled = true;
  exportBtn.disabled = true;

  console.log('Popup initialized, checking current state...');

  // Check if we're on Zealty.ca and get current state
  chrome.tabs.query({ active: true, currentWindow: true }, async function(tabs) {
    try {
      const isZealtyPage = tabs[0].url?.includes('zealty.ca');
      startBtn.disabled = !isZealtyPage;
      statusSpan.textContent = isZealtyPage ? 'Ready' : 'Please navigate to Zealty.ca';
      statusSpan.className = isZealtyPage ? '' : 'error';

      console.log('Checking extraction state...');
      // Get current extraction state
      const state = await chrome.storage.local.get(['isExtracting', 'recordCount', 'extractedData']);
      console.log('Current state:', state);

      if (state.isExtracting) {
        updateUI(true, state.recordCount || 0);
      }

      // Enable export if we have data
      if (state.extractedData?.length > 0) {
        exportBtn.disabled = false;
        recordCountSpan.textContent = state.extractedData.length;
      }
    } catch (error) {
      console.error('Initialization error:', error);
      statusSpan.textContent = 'Error initializing';
      statusSpan.className = 'error';
    }
  });

  startBtn.addEventListener('click', async () => {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab.url?.includes('zealty.ca')) {
        alert('Please navigate to Zealty.ca first');
        return;
      }

      console.log('Starting extraction...');
      await chrome.storage.local.set({ 
        isExtracting: true,
        extractedData: [],
        recordCount: 0
      });

      chrome.tabs.sendMessage(tab.id, { action: 'startExtraction' });
      updateUI(true, 0);
    } catch (error) {
      console.error('Start extraction error:', error);
      alert('Failed to start extraction. Please try again.');
    }
  });

  stopBtn.addEventListener('click', async () => {
    try {
      console.log('Stopping extraction...');
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      await chrome.storage.local.set({ isExtracting: false });
      chrome.tabs.sendMessage(tab.id, { action: 'stopExtraction' });
      updateUI(false);
    } catch (error) {
      console.error('Stop extraction error:', error);
      alert('Failed to stop extraction. Please try again.');
    }
  });

  exportBtn.addEventListener('click', () => {
    console.log('Starting CSV export...');
    statusSpan.textContent = 'Preparing export...';
    exportBtn.disabled = true;  // Disable to prevent multiple clicks

    // Set a timeout to re-enable the export button if the process gets stuck
    if (exportTimeout) {
      clearTimeout(exportTimeout);
    }
    exportTimeout = setTimeout(() => {
      console.warn('Export timeout reached');
      exportBtn.disabled = false;
      statusSpan.textContent = 'Export timed out';
      statusSpan.className = 'error';
    }, 30000); // 30 second timeout

    chrome.runtime.sendMessage({ action: 'exportCSV' });
  });

  // Listen for messages from content script and background
  chrome.runtime.onMessage.addListener((message) => {
    console.log('Received message:', message);

    // Clear any existing export timeout when receiving a message
    if (exportTimeout && (message.action === 'exportSuccess' || message.action === 'exportError')) {
      clearTimeout(exportTimeout);
      exportTimeout = null;
    }

    switch (message.action) {
      case 'updateRecordCount':
        recordCountSpan.textContent = message.count;
        exportBtn.disabled = message.count === 0;
        break;

      case 'exportProgress':
        statusSpan.textContent = message.message;
        statusSpan.className = '';
        break;

      case 'exportError':
        statusSpan.textContent = 'Export failed';
        statusSpan.className = 'error';
        exportBtn.disabled = false;  // Re-enable export button
        alert(message.message);
        break;

      case 'exportSuccess':
        statusSpan.textContent = 'Export complete';
        statusSpan.className = '';
        exportBtn.disabled = false;  // Re-enable export button
        // Reset status after a delay
        setTimeout(() => {
          statusSpan.textContent = 'Ready';
        }, 3000);
        break;
    }
  });

  function updateUI(isExtracting, recordCount) {
    startBtn.disabled = isExtracting;
    stopBtn.disabled = !isExtracting;
    statusSpan.textContent = isExtracting ? 'Extracting...' : 'Ready';
    statusSpan.className = '';  // Reset any error classes
    if (typeof recordCount !== 'undefined') {
      recordCountSpan.textContent = recordCount;
      exportBtn.disabled = recordCount === 0;
    }
  }
});